<?php

/**
 * Page Template
 * 
 * @package Imagify
 */

get_header();

?>

<div class="section">

    <p>
    <?php esc_html_e('Page.php', 'imagify'); ?>
    </p>
</div>

<?php
get_footer();
?>