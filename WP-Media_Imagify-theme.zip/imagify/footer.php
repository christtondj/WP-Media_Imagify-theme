<?php

/**
 * Footer template
 * 
 * @package Imagify
 */
?>


<?php wp_footer(); ?>
</body>

</html>