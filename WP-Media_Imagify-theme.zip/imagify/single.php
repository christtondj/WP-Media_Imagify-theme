<?php

/**
 * Single Template
 * 
 * @package Imagify
 */

get_header();

?>

<div class="section">

    <p>
        <?php esc_html_e('Single.php', 'imagify'); ?>
    </p>
</div>

<?php
get_footer();
?>